package com.cg.bam.test;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cg.bam.exception.BankAccountException;
import com.cg.bam.service.BankAccountService;
import com.cg.bam.service.BankAccountServiceImpl;

public class TestClass {

	
    
    @Test
    public void test_validateName_v1() throws BankAccountException{
    
        String name="Mansi121";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
   
    @Test
    public void test_validateName_v3() throws BankAccountException{
    
        String name="mansi";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test(expected=BankAccountException.class)
    public void test_ValidateMobNo_null() throws BankAccountException{
        BankAccountService service=new BankAccountServiceImpl();
        service.validateMoileNo(null);
    }
    
    @Test
    public void test_validateMobNo_v2() throws BankAccountException{
    
        String mobNo="7895446824";
        BankAccountService service=new BankAccountServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(true,result);
    }
   
	
}
