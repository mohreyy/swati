package com.cg.bam.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bam.dto.Customer;

public class DataStore {
	private static Map<String, Customer> customer;
	static Map<String, Customer> createCollection(){
		if(customer == null)
			customer = new HashMap<>();		
		customer.put("7895446824", new Customer("Mansi","7895446824",10000));
		customer.put("9319998020", new Customer("Jps","9319998020",8000));
		customer.put("7895495769", new Customer("Shubhrat","7895495769",18570));
		
		
		return customer;		
	}

}
