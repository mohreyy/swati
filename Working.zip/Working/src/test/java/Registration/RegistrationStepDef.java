package Registration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.RegistraionPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDef {
	private WebDriver driver;
	private RegistraionPageFactory obj;
	

	@Given("^user is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver =new FirefoxDriver();
		   Thread.sleep(1000);
		   obj = new RegistraionPageFactory(driver);
		   driver.get("file:///D:/Module%203/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		
		
	}

	@Then("^check the heading of page$")
	public void check_the_heading_of_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		String title = driver.getTitle();
	    if(title.equals("Email Registration Forms")) {
	    	System.out.println("Title Correct");
	    }else {
	    	System.out.println("Title Wrong!");
	    }
		
	}

	@When("^password and confirm password are not same$")
	public void password_and_confirm_password_are_not_same() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		driver.manage().window().maximize();
		obj.setPassword("capg");
		obj.setCpassword("capgemini");
		obj.setPfconfirm();
		
	}

	@Then("^prompt user to write same password$")
	public void prompt_user_to_write_same_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		driver.switchTo().alert();
	    Thread.sleep(1000);
	    driver.switchTo().alert().accept();
	    Thread.sleep(1000);
	    obj.setPassword("capg");
	    Thread.sleep(1000);
	    obj.setCpassword("capg");
		
		
	}
	
	

@When("^all details are correct$")
public void all_details_are_correct() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   // throw new PendingException();
	obj.setUsername("mohrey");
	 Thread.sleep(1000);
	obj.setPassword("capg");
	 Thread.sleep(1000);
	obj.setCpassword("capg");
	 Thread.sleep(1000);
	obj.setFname("Mansi");
	 Thread.sleep(1000);
	obj.setLname("Ohrey");
	 Thread.sleep(1000);
	obj.setRadiogender("Female");
	 Thread.sleep(1000);
	obj.setDateofbirth("31/03/1996");
	 Thread.sleep(1000);
	obj.setEmail("mansi.ohrey31@gmail.com");
	 Thread.sleep(1000);
	obj.setCity("Pune");
	 Thread.sleep(1000);
	obj.setPhone("7895446824");
	 Thread.sleep(1000);
	obj.setCheckBox("Music");
	 Thread.sleep(1000);
	obj.setPfconfirm();
	
	
}

@Then("^navigate to success page$")
public void navigate_to_success_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   // throw new PendingException();
	
	
	//driver.navigate().to("file:///D:/Module%203/hotelBooking/success.html");
	System.out.println("successful");
    Thread.sleep(3000);
    driver.close();
	
}

	
	
	
	
	
	

}
