package PageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistraionPageFactory {
	
	WebDriver driver;
	
	@FindBy(id="txtUserName")
	WebElement username;
	
	@FindBy(id="txtPassword")
	WebElement password;
	
	@FindBy(id="txtConfPassword")
	WebElement cpassword;
	
	@FindBy(id="txtFirstName")
	WebElement fname;
	
	
	@FindBy(id="txtLastName")
	WebElement lname;
	
	
	@FindBy(name="submit")
	WebElement pfconfirm;
	
	@FindBy(name="City")
	WebElement city;
	
	@FindBy(id="txtPhone")
	WebElement phone;
	
	@FindBy(id="txtEmail")
	WebElement email;
	
	@FindBy(name="gender")
	WebElement radiogender;
	
	@FindBy(name="chkHobbies")
	WebElement pfCheckBox;
	
	
	@FindBy(id="DOB")
	WebElement dateofbirth;
	
	
	public RegistraionPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getUsername() {
		return username;
	}


	public void setUsername(String uname) {
	username.sendKeys(uname);
	}


	public WebElement getPassword() {
		return password;
	}


	public void setPassword(String psswrd) {
		password.sendKeys(psswrd);
	}





	public WebElement getCpassword() {
		return cpassword;
	}





	public void setCpassword(String cpwd) {
		cpassword.sendKeys(cpwd);
	}





	public WebElement getFname() {
		return fname;
	}





	public void setFname(String fstname) {
		fname.sendKeys(fstname);
	}





	public WebElement getLname() {
		return lname;
	}





	public void setLname(String lstname) {
		lname.sendKeys(lstname);
	}





	public WebElement getCity() {
		return city;
	}

	public void setCity(String pcity) {
		Select sel = new Select(city);
		sel.selectByVisibleText(pcity);
	}

	
	
	
	
	
	public WebElement getPhone() {
		return phone;
	}

	public void setPhone(String phoneno) {
		phone.sendKeys(phoneno);
	}
	
	
	
	
	
	
	
	
	

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String mail) {
		email.sendKeys(mail);
	}
	
	
	
	
	
	
	
	
	

	public WebElement getRadiogender() {
		return radiogender;
	}

	public void setRadiogender(String gender) {
		if(gender.equals("Male"))
		{
			radiogender.findElement(By.xpath("//*[@id='rbMale']")).click();
		}
		else
			radiogender.findElement(By.xpath("//*[@id='rbFemale']")).click();
	}

	
	
	
	
	
	
	
	
	public WebElement getCheckBox() {
		return pfCheckBox;
	}

	
	public void setCheckBox(String check) {
		if(check.equals("Music"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input[1]")).click();
		}
		else if(check.equals("Reading"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input[2]")).click();
		}
		else if(check.equals("Movies"))
		{
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input[3]")).click();
		}
	}

	
	

	
	
	public WebElement getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dob) {
		dateofbirth.sendKeys(dob);
	}

	
	
	
	public WebElement getPfconfirm() {
		return pfconfirm;
	}

	public void setPfconfirm() {
		pfconfirm.click();
	}
	
	
	
	

	
	
	

}
